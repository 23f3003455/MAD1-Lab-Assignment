import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from jinja2 import Template


def run():
    args = sys.argv[1:]
    data = pd.read_csv("data.csv")

    # Strip whitespace from column names
    data.columns = data.columns.str.strip()

    if not args or len(args) < 2:
        show_error_page()
        return

    flag, value = args[0], args[1]

    if flag == "-s":
        html_result = handle_student(data, value)
    elif flag == "-c":
        html_result = handle_course(data, value)
    else:
        show_error_page()
        return

    save_html(html_result)


def handle_student(dataset, student_id):
    try:
        student_id = int(student_id)
    except ValueError:
        show_error_page()
        sys.exit()

    student_data = dataset.loc[dataset["Student id"] == student_id]

    if student_data.empty:
        show_error_page()
        sys.exit()

    total_marks = student_data["Marks"].sum()

    student_html = """<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Student Data</title></head>
<style>
    table, th, td { border: 1px solid black; border-collapse: collapse; }
    th, td { padding: 5px; }
</style>
<body>
    <h1>Student Details</h1>
    <table>
        <thead>
            <tr>
                <th>Student id</th>
                <th>Course id</th>
                <th>Marks</th>
            </tr>
        </thead>
        <tbody>
            {% for entry in data %}
            <tr>
                <td>{{ entry['Student id'] }}</td>
                <td>{{ entry['Course id'] }}</td>
                <td>{{ entry['Marks'] }}</td>
            </tr>
            {% endfor %}
            <tr>
                <td colspan="2"><b>Total Marks</b></td>
                <td>{{ total }}</td>
            </tr>
        </tbody>
    </table>
</body>
</html>"""

    tmpl = Template(student_html)
    return tmpl.render(data=student_data.to_dict(orient="records"), total=total_marks)


def handle_course(dataset, course_id):
    try:
        course_id = int(course_id)
    except ValueError:
        show_error_page()
        sys.exit()

    course_info = dataset.loc[dataset["Course id"] == course_id]

    if course_info.empty:
        show_error_page()
        sys.exit()

    avg_score = course_info["Marks"].mean()
    best_score = course_info["Marks"].max()

    plot_marks_distribution(course_info)

    course_html = """<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Course Data</title></head>
<style>
    table, th, td { border: 1px solid black; border-collapse: collapse; }
    th, td { padding: 5px; }
</style>
<body>
    <h1>Course Details</h1>
    <table>
        <thead>
            <tr>
                <th>Average Marks</th>
                <th>Maximum Marks</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>{{ avg }}</td>
                <td>{{ top }}</td>
            </tr>
        </tbody>
    </table>
    <img src="bar_chart.png" alt="Bar Chart" height="250">
</body>
</html>"""

    tmpl = Template(course_html)
    return tmpl.render(avg=round(avg_score, 2), top=best_score)


def plot_marks_distribution(df):
    marks_distribution = df["Marks"].value_counts().sort_index()
    marks = np.array(marks_distribution.index)

    start = (marks.min() // 10) * 10

    plt.figure(figsize=(10, 6))
    plt.bar(marks, marks_distribution.values, width=1.0, align="center")
    plt.xlim(start, 100)
    plt.xticks(range(start, 101, 10))
    plt.xlabel("Marks")
    plt.ylabel("Frequency")
    plt.grid(axis="y", linestyle="--", alpha=0.6)
    plt.tight_layout()
    plt.savefig("bar_chart.png", dpi=300)
    plt.close()


def show_error_page():
    error_html = """<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Something Went Wrong</title></head>
<body>
    <h1>Wrong Inputs</h1>
    <p>Something went wrong</p>
</body>
</html>"""
    save_html(error_html)


def save_html(content):
    with open("output.html", "w", encoding="utf-8") as file:
        file.write(content)
    print("Output saved to output.html")


if __name__ == "__main__":
    run()
